import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route } from 'react-router-dom';
import CustomerView from '../CustomerView';
import { staffService } from '../../apiUrls';


// Mock the staffService module
jest.mock('../../apiUrls', () => ({
  staffService: {
    viewCustomer: jest.fn(),
  },
}));

const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

describe('CustomerView Component', () => {

  const mockCustomerData = {
    results: [
      { id: 1, user_firstname: 'John', user_lastname: 'Doe', accountNumber: '123' },
      { id: 2, user_firstname: 'Jane', user_lastname: 'Doe', accountNumber: '456' },
    ],
  };
  it('displays customer data and navigates to view transaction on button click', async () => {
    
   

    
    render(
      <MemoryRouter><CustomerView /></MemoryRouter>
    );

    
    await waitFor(() => {
      expect(staffService.viewCustomer).toHaveBeenCalledTimes(1);
    });

  
  });

  it('handles view transaction navigation correctly', async () => {

    staffService.viewCustomer.mockResolvedValueOnce({
      data: mockCustomerData,
    });

    render(<MemoryRouter><CustomerView /></MemoryRouter>);


    await waitFor(() => expect(staffService.viewCustomer).toHaveBeenCalledTimes(2));

    fireEvent.click(screen.getByRole('button', { name: /View/i }));

  
  });
 
});
