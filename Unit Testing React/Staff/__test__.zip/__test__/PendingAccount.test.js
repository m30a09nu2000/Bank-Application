import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { staffService } from '../../apiUrls'; 
import PendingAccount from '../PendingAccount';
import { MemoryRouter } from 'react-router-dom';


jest.mock('../../apiUrls', () => ({
  staffService: {
    pendingaccount: jest.fn(),
    updateaccount: jest.fn(),
  },
}));


describe('PendingAccount Component', () => {
  
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('fetches and displays pending account data', async () => {
    
    staffService.pendingaccount.mockResolvedValue({
      data: [
        { account_number: '123', status: 'pending', account_type: 'savings' },
        { account_number: '456', status: 'pending', account_type: 'current' },
      ],
    });

   
    render(<MemoryRouter><PendingAccount /></MemoryRouter>);

  
    await waitFor(() => {
        expect(staffService.pendingaccount).toHaveBeenCalledTimes(1);
        
    });
  });
 
  it('handles account approval', async () => {
    const mockAccountNumber = '123';
  
    
    render(<MemoryRouter><PendingAccount /></MemoryRouter>); 
  
    await waitFor(() => {
      const buttons = screen.getAllByTestId('button1');
    
      const button = buttons[0];
      userEvent.click(button);
    });
  
    expect(staffService.pendingaccount).toHaveBeenCalledTimes(1);
    expect(staffService.updateaccount).toHaveBeenCalledWith({
      account_number: mockAccountNumber,
      status: 'approved',
    });
   
  
    
  })
  it('handles account reject', async () => {
    const mockAccountNumber = '123';
  
    
    render(<MemoryRouter><PendingAccount /></MemoryRouter>); 
  
    await waitFor(() => {
      const buttons = screen.getAllByTestId('button2');
    
      const button = buttons[0];
      userEvent.click(button);
    });
  
    expect(staffService.pendingaccount).toHaveBeenCalledTimes(1);
    expect(staffService.updateaccount).toHaveBeenCalledWith({
      account_number: mockAccountNumber,
      status: 'rejected',
    });

 
  })
})
