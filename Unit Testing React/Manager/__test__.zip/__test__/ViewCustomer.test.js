import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import ViewCustomer from '../ViewCustomer';
import { managerService } from '../../apiUrls';
import { axiosPrivate } from '../../interceptor';
import { act } from 'react-dom/test-utils'; 
jest.mock('../../apiUrls', () => ({
  managerService: {
    viewCustomer: jest.fn(),
  },
}));

jest.mock('../../interceptor', () => ({
  axiosPrivate: jest.fn(),
}));

describe('ViewCustomer', () => {

    afterEach(() => {
        jest.clearAllMocks();
      });
  const mockCustomerData = {
    results: [
      { id: 1, user_firstname: 'John', user_lastname: 'Doe', email: 'john.doe@example.com', phone: '555-1234', user_address: '123 Main St' },
      { id: 2, user_firstname: 'Jane', user_lastname: 'Doe', email: 'jane.doe@example.com', phone: '555-5678', user_address: '456 Oak St' },
    ],
    next_page: '/api/customer/?page=2',
    previous_page: null,
  };

  it('fetches and displays staff data on mount', async () => {
    managerService.viewCustomer.mockResolvedValueOnce({
      data: mockCustomerData,
    });

    render(
      <MemoryRouter initialEntries={['/view-customer']}>
        <Routes>
          <Route path="/view-customer" element={<ViewCustomer />} />
        </Routes>
      </MemoryRouter>
    );
  
    await waitFor(() => expect(managerService.viewCustomer).toHaveBeenCalledTimes(1));

    
  });

  
  it('handles pagination on button click', async () => {
    managerService.viewCustomer.mockResolvedValueOnce({
      data: mockCustomerData,
    });

    axiosPrivate.mockResolvedValueOnce({
      data: {
        results: [
          { id: 3, user_firstname: 'Alice', user_lastname: 'Smith', email: 'alice.smith@example.com', phone: '555-9876', user_address: '789 Pine St' },
        ],
        next_page: '/api/customer/?page=3',
        previous_page: '/api/customer/?page=1',
      },
    });

    render(
      <MemoryRouter initialEntries={['/view-customer']}>
        <Routes>
          <Route path="/view-customer" element={<ViewCustomer />} />
        </Routes>
      </MemoryRouter>
    );

    
    await waitFor(() => expect(managerService.viewCustomer).toHaveBeenCalledTimes(1));
   
    fireEvent.click(screen.getByRole('button', { name: /Next/i }));
   
    await waitFor(() => expect(axiosPrivate).toHaveBeenCalledTimes(1));
    
  });

 
})
