

import { render, screen, fireEvent, waitFor, getByRole } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import   Register from '../Register'
import { customerService } from '../../apiUrls';
import userEvent from '@testing-library/user-event';

jest.mock('../../apiUrls', () => ({
    customerService: {
      registration: jest.fn()
    },
  }));

describe('Registration Component', () => {

    afterEach(() => {
        jest.clearAllMocks();
      });
   
    it('button in the component', async () => {
      // Render the component with MemoryRouter to provide routing context
      render(
        <MemoryRouter>
          <Register />
        </MemoryRouter>
        
      );
      expect(screen.getByRole("button")).toBeInTheDocument()
    })

    it("should render button with given name", () => {
        render(<MemoryRouter>
            <Register />
        </MemoryRouter>)
        const loginButton = screen.getByRole("button", { name: /register/i })
        expect(loginButton).toBeInTheDocument()
        // -- assert Text --
        expect(loginButton).toHaveTextContent(/register/i)

})

it('submits the registration form with valid input', async () => {
    const { getByLabelText, getByTestId,getByRole } = render(<MemoryRouter><Register /></MemoryRouter>);


    expect(getByLabelText(/First Name/i)).toBeInTheDocument();
    expect(getByLabelText(/Last Name/i)).toBeInTheDocument();
    expect(getByLabelText(/Email/i)).toBeInTheDocument();
    expect(getByLabelText(/Address/i)).toBeInTheDocument();
    expect(getByLabelText(/Phone/i)).toBeInTheDocument();
    expect(getByLabelText(/Password/i)).toBeInTheDocument();

    expect(getByRole('button')).toBeInTheDocument();

})

it('submits the registration form with valid input', async () => {

   
    const { getByLabelText, getByTestId } = render(<MemoryRouter><Register /></MemoryRouter>);

    
    fireEvent.change(screen.getByLabelText(/First Name/i), { target: { value: 'John' } });
    fireEvent.change(screen.getByLabelText(/Last Name/i), { target: { value: 'Doe' } });
    fireEvent.change(screen.getByLabelText(/Address/i), { target: { value: 'Some Address' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'john.doe@example.com' } });
    fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'password123' } });
    fireEvent.change(screen.getByLabelText(/Phone/i), { target: { value: '1234567890' } });

    fireEvent.click(screen.getByRole('button', { name: /register/i }));
   
   
    
  });
  
  
  
  
  
  
  
    

jest.clearAllMocks();
})





