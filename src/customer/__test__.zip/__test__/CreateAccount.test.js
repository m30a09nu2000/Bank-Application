import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { customerService } from '../../apiUrls';
import CreateAccount from '../CreateAccount';

jest.mock('../../apiUrls', () => ({
  customerService: {
    createaccount: jest.fn(),
  },
}));

// Mock the window.alert function
const mockAlert = jest.fn();
global.alert = mockAlert;

// Describe the tests for the CreateAccount component
describe('CreateAccount Component', () => {
  // Test case for successful form submission
  it('submits the create account form with valid input', async () => {
    // Mock the createaccount function to resolve with a success response
    customerService.createaccount.mockResolvedValue({
      data: 'Account Created Successfully',
    });

    // Render the CreateAccount component
    const { getByLabelText, getByRole } = render(<CreateAccount />);

    // Change the select input value
    fireEvent.change(getByLabelText(/AccountType/i), { target: { value: 'savings' } });

    // Click the submit button
    fireEvent.click(getByRole('button', { name: /Create Account/i }));

    // Wait for the asynchronous code to resolve
    await waitFor(() => {});

    // Check if the createaccount function was called with the correct arguments
    expect(customerService.createaccount).toHaveBeenCalledWith({ account_type: 'savings' });

    // Check if the success alert was displayed
    expect(mockAlert).toHaveBeenCalledWith('Account Created Successfully');
  });
});
